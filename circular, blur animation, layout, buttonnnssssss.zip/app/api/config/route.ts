import { NextResponse } from "next/server"

export async function GET() {
  const clipdropConfigured = Boolean(process.env.CLIPDROP_API_KEY)
  return NextResponse.json({ clipdropConfigured })
}
