import { cn } from "@/lib/utils"

type SpinnerProps = {
  size?: number
  className?: string
}

/**
 * Minimal spinner that inherits current text color.
 * Uses an outer stroked ring and a filled arc for motion.
 */
export function Spinner({ size = 16, className }: SpinnerProps) {
  const s = size
  return (
    <svg
      className={cn("animate-spin text-current", className)}
      width={s}
      height={s}
      viewBox="0 0 24 24"
      aria-hidden="true"
      role="status"
    >
      {/* Track */}
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
      {/* Indicator */}
      <path className="opacity-75" fill="currentColor" d="M12 2a10 10 0 0 1 10 10h-4a6 6 0 0 0-6-6V2z" />
    </svg>
  )
}
