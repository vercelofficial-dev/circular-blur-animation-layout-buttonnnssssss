"use client"

import type React from "react"

import { useEffect, useState } from "react"

interface Spark {
  id: string
  x: number
  y: number
  angle: number
  velocity: number
  life: number
  maxLife: number
}

interface ClickSparkProps {
  children: React.ReactNode
  className?: string
  sparkCount?: number
  sparkColor?: string
  disabled?: boolean
}

export function ClickSpark({
  children,
  className = "",
  sparkCount = 8,
  sparkColor = "#ffffff",
  disabled = false,
}: ClickSparkProps) {
  const [sparks, setSparks] = useState<Spark[]>([])

  const createSparks = (x: number, y: number) => {
    if (disabled) return

    const newSparks: Spark[] = []

    for (let i = 0; i < sparkCount; i++) {
      const angle = (Math.PI * 2 * i) / sparkCount + (Math.random() - 0.5) * 0.5
      const velocity = 2 + Math.random() * 3
      const maxLife = 60 + Math.random() * 30

      newSparks.push({
        id: `${Date.now()}-${i}`,
        x,
        y,
        angle,
        velocity,
        life: maxLife,
        maxLife,
      })
    }

    setSparks((prev) => [...prev, ...newSparks])
  }

  const handleClick = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    createSparks(x, y)

    // Trigger haptic feedback if available
    if (navigator.vibrate) {
      navigator.vibrate(50)
    }
  }

  useEffect(() => {
    if (sparks.length === 0) return

    const interval = setInterval(() => {
      setSparks((prev) =>
        prev
          .map((spark) => ({
            ...spark,
            x: spark.x + Math.cos(spark.angle) * spark.velocity,
            y: spark.y + Math.sin(spark.angle) * spark.velocity,
            life: spark.life - 1,
            velocity: spark.velocity * 0.98,
          }))
          .filter((spark) => spark.life > 0),
      )
    }, 16)

    return () => clearInterval(interval)
  }, [sparks])

  return (
    <div className={`relative overflow-hidden ${className}`} onClick={handleClick}>
      {children}

      {/* Spark particles */}
      {sparks.map((spark) => {
        const opacity = spark.life / spark.maxLife
        const scale = 1 - (spark.life / spark.maxLife) * 0.5

        return (
          <div
            key={spark.id}
            className="absolute pointer-events-none"
            style={{
              left: spark.x,
              top: spark.y,
              transform: `translate(-50%, -50%) scale(${scale})`,
              opacity,
            }}
          >
            <div
              className="w-1 h-1 rounded-full"
              style={{
                backgroundColor: sparkColor,
                boxShadow: `0 0 6px ${sparkColor}`,
              }}
            />
          </div>
        )
      })}
    </div>
  )
}
