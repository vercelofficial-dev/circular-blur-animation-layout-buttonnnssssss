"use client"

import { useToast } from "@/hooks/use-toast"
import { Toast, ToastClose, ToastDescription, ToastProvider, ToastTitle, ToastViewport } from "@/components/ui/toast"
import { AlertOctagon, CheckCircle2 } from "lucide-react"

export function Toaster() {
  const { toasts } = useToast()

  return (
    <ToastProvider>
      {toasts.map(({ id, title, description, action, ...props }) => {
        const isError = props.variant === "destructive"
        return (
          <Toast key={id} {...props}>
            {/* Content row with leading icon */}
            <div className="flex w-full items-start gap-3">
              <div className="mt-0.5 shrink-0">
                {isError ? (
                  <AlertOctagon className="h-5 w-5 text-[#f87272]" aria-hidden="true" />
                ) : (
                  <CheckCircle2 className="h-5 w-5 text-[#48dd7f]" aria-hidden="true" />
                )}
              </div>
              <div className="grid flex-1 gap-1">
                {title && <ToastTitle>{title}</ToastTitle>}
                {description && <ToastDescription>{description}</ToastDescription>}
              </div>
              {action}
            </div>
            <ToastClose />
          </Toast>
        )
      })}
      <ToastViewport />
    </ToastProvider>
  )
}
