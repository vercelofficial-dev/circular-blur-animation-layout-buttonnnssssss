import type React from "react"

interface ShinyTextProps {
  text: string
  disabled?: boolean
  speed?: number
  className?: string
}

const ShinyText: React.FC<ShinyTextProps> = ({ text, disabled = false, speed = 1.8, className = "" }) => {
  const animationDuration = `${speed}s`

  return (
    <span
      className={`inline-block ${disabled ? "" : "animate-shine"} ${className}`}
      style={{
        background: disabled
          ? "currentColor"
          : "linear-gradient(120deg, rgba(255,255,255,0.12) 0%, rgba(255,255,255,0.22) 42%, rgba(255,255,255,0.98) 50%, rgba(255,255,255,0.22) 58%, rgba(255,255,255,0.12) 100%)",
        backgroundSize: "300% 100%",
        WebkitBackgroundClip: "text",
        backgroundClip: "text",
        WebkitTextFillColor: disabled ? "currentColor" : "transparent",
        color: "currentColor",
        animationDuration,
        filter: disabled
          ? undefined
          : "drop-shadow(0 0 6px rgba(255,255,255,0.18)) drop-shadow(0 0 12px rgba(255,255,255,0.12))",
        ["--shine-duration" as any]: animationDuration,
      }}
    >
      {text}
    </span>
  )
}

export default ShinyText
