type Props = {
  size?: number
  color?: string
  className?: string
}

import "./geist-spinner.css"

export default function GeistSpinner({ size = 21, color = "currentColor", className = "" }: Props) {
  const spokes = Array.from({ length: 12 })
  const center = 12
  const opacityTrail = [1, 0.92, 0.84, 0.76, 0.68, 0.6, 0.52, 0.44, 0.36, 0.28, 0.2, 0.12]

  return (
    <svg
      width={size}
      height={size}
      style={{ width: `${size}px`, height: `${size}px`, minWidth: `${size}px`, minHeight: `${size}px` }}
      viewBox="0 0 24 24"
      aria-label="Loading"
      role="status"
      className={`geist-spinner ${className}`}
    >
      {spokes.map((_, i) => (
        <line
          key={i}
          className="spoke"
          x1={center}
          y1={center - 9}
          x2={center}
          y2={center - 6}
          opacity={opacityTrail[i]}
          transform={`rotate(${i * 30} ${center} ${center})`}
          stroke={color}
          strokeWidth="2"
          strokeLinecap="round"
        />
      ))}
    </svg>
  )
}
