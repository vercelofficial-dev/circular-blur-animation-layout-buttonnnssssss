"use client"

import type React from "react"

import { useTheme } from "next-themes"
import { Toaster as Sonner, type ToasterProps } from "sonner"

const Toaster = ({ ...props }: ToasterProps) => {
  const { theme = "system" } = useTheme()

  return (
    <>
      <Sonner
        theme={theme as ToasterProps["theme"]}
        className="toaster group"
        style={
          {
            // base/normal (success/neutral green)
            "--normal-bg": "#0b2211",
            "--normal-text": "#49b35f",
            "--normal-border": "#2e4234",
            // success palette (kept for reference, not required since we style non-error globally)
            "--success-bg": "#0b2211",
            "--success-text": "#49b35f",
            "--success-border": "#2e4234",
            // error palette
            "--error-bg": "#340b09",
            "--error-text": "#f87272",
            "--error-border": "#4c2926",
          } as React.CSSProperties
        }
        {...props}
      />
      {/* Apply the custom colors to Sonner toasts */}
      <style jsx global>{`
        /* All non-error toasts (default, success, info, warning, loading, etc.) */
        .toaster [data-sonner-toast]:not([data-type="error"]) {
          background: var(--normal-bg) !important;
          color: var(--normal-text) !important;
          border: 1px solid var(--normal-border) !important;
        }
        .toaster
          [data-sonner-toast]:not([data-type="error"])
          [data-title],
        .toaster
          [data-sonner-toast]:not([data-type="error"])
          [data-description],
        .toaster
          [data-sonner-toast]:not([data-type="error"])
          [data-icon] {
          color: var(--normal-text) !important;
        }
        .toaster
          [data-sonner-toast]:not([data-type="error"])
          button,
        .toaster
          [data-sonner-toast]:not([data-type="error"])
          a {
          color: var(--normal-text) !important;
          border-color: var(--normal-border) !important;
        }

        /* Error toast stays red and subtext matches title color */
        .toaster [data-sonner-toast][data-type="error"] {
          background: var(--error-bg) !important;
          color: var(--error-text) !important;
          border: 1px solid var(--error-border) !important;
        }
        .toaster [data-sonner-toast][data-type="error"] [data-title],
        .toaster [data-sonner-toast][data-type="error"] [data-description],
        .toaster [data-sonner-toast][data-type="error"] [data-icon] {
          color: var(--error-text) !important;
        }
        .toaster [data-sonner-toast][data-type="error"] button,
        .toaster [data-sonner-toast][data-type="error"] a {
          color: var(--error-text) !important;
          border-color: var(--error-border) !important;
        }

        /* Fix vertical text and enforce horizontal layout for "large" toasts with description */
        .toaster [data-sonner-toast]:has([data-description]) {
          border-radius: 14px;
          padding: 12px 16px;
          min-height: 64px;
          /* Layout: icon | text | action */
          display: grid;
          grid-template-columns: 22px 1fr auto;
          align-items: center;
          gap: 12px;
          max-width: min(620px, calc(100vw - 24px));
          writing-mode: horizontal-tb;
          text-orientation: mixed;
          overflow: hidden;
        }

        /* Center and enlarge icons on all "large" toasts */
        .toaster [data-sonner-toast]:has([data-description]) [data-icon] {
          grid-column: 1;
          width: 22px; /* was 18px */
          height: 22px; /* was 18px */
          align-self: center; /* was start */
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }

        /* When a "large" toast has NO icon, remove the empty icon column and shift text left */
        .toaster [data-sonner-toast]:has([data-description]):not(:has([data-icon])) {
          grid-template-columns: 1fr auto; /* collapse icon column */
          padding-left: 16px; /* keep consistent inner spacing */
        }
        .toaster
          [data-sonner-toast]:has([data-description]):not(:has([data-icon]))
          [data-content] {
          grid-column: 1;
          margin-left: 0 !important;
        }
        .toaster
          [data-sonner-toast]:has([data-description]):not(:has([data-icon]))
          [data-close-button] {
          grid-column: 2;
        }

        /* For any toast (thin or large) without an icon, ensure text is flush left */
        .toaster [data-sonner-toast]:not(:has([data-icon])) [data-content] {
          margin-left: 0 !important;
        }
        .toaster [data-sonner-toast]:not(:has([data-icon])) {
          padding-left: 14px; /* removes phantom left gap on text-only toasts */
        }

        /* For any toast that DOES have an icon (including thin toasts), center the icon and size it up slightly */
        .toaster [data-sonner-toast]:has([data-icon]) [data-icon] {
          width: 22px;
          height: 22px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          align-self: center;
        }

        /* Typography: enforce horizontal flow and normal wrapping to prevent vertical characters */
        .toaster [data-sonner-toast]:has([data-description]) [data-title],
        .toaster
          [data-sonner-toast]:has([data-description])
          [data-description] {
          writing-mode: horizontal-tb !important;
          text-orientation: mixed !important;
          white-space: normal !important;
          word-break: normal !important;
          overflow-wrap: anywhere;
          display: block;
        }

        .toaster [data-sonner-toast]:has([data-description]) [data-title] {
          font-family: "DiamondGrotesk", sans-serif;
          font-weight: 400;
          font-size: 16px;
          line-height: 1.2;
          letter-spacing: 0.2px;
        }
        .toaster [data-sonner-toast]:has([data-description]) [data-description] {
          font-family: "DiamondGrotesk", sans-serif;
          font-weight: 400;
          font-size: 14px;
          line-height: 1.4;
          margin-top: 2px;
        }

        /* Thin toasts are those without a description node */
        .toaster [data-sonner-toast]:not(:has([data-description])) {
          border-radius: 14px; /* match thicker toast pills without changing height/width */
        }
        .toaster
          [data-sonner-toast]:not(:has([data-description]))
          [data-title] {
          font-family: "DiamondGrotesk", sans-serif;
          /* keep existing size/line-height from Sonner/shadcn to avoid size changes */
        }
      `}</style>
    </>
  )
}

export { Toaster }
